# Saurav Avachat — Portfolio Website

A responsive, single-page personal portfolio built with plain HTML, CSS, and JavaScript.

## Preview locally
Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Create a GitHub repository named `saurav3103.github.io` (or any repository for project Pages).
2. Upload `index.html` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site.

## Before publishing
- Check the public contact details you want to show.
- Add links to project repositories / write-ups where available.
- Optionally add a PDF copy of your CV and a profile photo.
- Confirm all resume figures and publication status are still current.

The site is static and does not require a build step or backend.
